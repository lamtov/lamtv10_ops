#taskset -cp 22 java -cp target/eventstore-1.0.jar:target/lib/* -DnumberMsgStatistic=5000000 com.viettel.cba.eventstore.run.EventStoreMain
java -cp target/eventstore-1.0.jar:target/lib/* -DnumberMsgStatistic=5000000 com.viettel.cba.eventstore.run.EventStoreMain

