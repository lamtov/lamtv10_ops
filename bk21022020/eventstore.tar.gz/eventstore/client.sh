taskset -cp 0,2,4,6,8,10,12,14,16,18,20,22 java -cp target/eventstore-1.0.jar:target/lib/* -Dhost=10.60.145.54 -Dsize=512 -DmaxTps=2000000 -Dtotal=10000000000 -DnumberMsgStatistic=5000000 com.viettel.cba.eventstore.client.EventClient

