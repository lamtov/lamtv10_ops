## Ceph samples

| file name | Description |
| ----------| ------------|
| new_osd.json | Add an osd to an existing cluster Use the new_osd.json sample file to describe your target OSD enviroment, then submit the POST request |
