#!/bin/sh

set -e
set -u

pip install tox;
