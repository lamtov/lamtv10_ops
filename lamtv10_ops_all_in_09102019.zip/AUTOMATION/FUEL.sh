FUEL
https://docs.openstack.org/fuel-docs/latest/userdocs/fuel-user-guide/verify-environment/intro-health-checks.html